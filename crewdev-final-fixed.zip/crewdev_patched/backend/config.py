from pydantic_settings import BaseSettings
from pathlib import Path


class Settings(BaseSettings):
    # ── LLM Provider Keys (all optional — configure via Settings UI) ──────────
    anthropic_api_key: str = ""
    openai_api_key: str = ""
    azure_api_key: str = ""
    azure_api_base: str = ""
    azure_api_version: str = ""

    # ── Ollama (local or cloud) ───────────────────────────────────────────────
    # Local:  OLLAMA_BASE_URL=http://localhost:11434  (no key needed)
    # Cloud:  OLLAMA_BASE_URL=https://ollama.com  +  OLLAMA_API_KEY=ollama_...
    ollama_base_url: str = ""
    ollama_api_key: str = ""

    # ── Optional enhanced features ────────────────────────────────────────────
    voyage_api_key: str = ""      # Better embeddings; falls back to sentence-transformers
    tavily_api_key: str = ""      # Web search in agent mode

    # ── App ───────────────────────────────────────────────────────────────────
    # IMPORTANT: set this in .env and back it up — losing it makes stored
    # provider keys unreadable (they are Fernet-encrypted with this secret).
    app_secret: str = ""

    # ── Database ──────────────────────────────────────────────────────────────
    # Default: SQLite — zero install, file auto-created on first run.
    # Production: DATABASE_URL=postgresql+asyncpg://user:pass@host/db
    database_url: str = "sqlite+aiosqlite:///./crewdev.db"

    # ── Paths ─────────────────────────────────────────────────────────────────
    chroma_path: str = "./chroma_db"
    workspace_path: str = "./workspace"

    # ── Models ────────────────────────────────────────────────────────────────
    llm_model: str = "claude-sonnet-4-6"
    embed_model: str = "voyage-3"

    # ── Agent config ──────────────────────────────────────────────────────────
    max_validation_iter: int = 3
    max_agent_iter: int = 5
    short_term_history_k: int = 20
    max_request_tokens: int = 200_000

    class Config:
        env_file = ".env"
        extra = "ignore"


settings = Settings()

Path(settings.chroma_path).mkdir(parents=True, exist_ok=True)
Path(settings.workspace_path).mkdir(parents=True, exist_ok=True)
