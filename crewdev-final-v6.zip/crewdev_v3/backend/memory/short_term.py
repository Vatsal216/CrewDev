"""
Short-term memory — pure Python in-process store.
No Redis required. Data lives in memory for the process lifetime.
TTL (7 days) and size-trimming replicate the original Redis behaviour exactly.
"""
import json
import time
from typing import Optional
from config import settings

# session_id → {"history": [...], "expires": float, "agent_states": {...}}
_store: dict[str, dict] = {}


def _bucket(session_id: str) -> dict:
    now = time.time()
    bucket = _store.get(session_id)
    if bucket is None or now > bucket["expires"]:
        bucket = {
            "history": [],
            "expires": now + 86400 * 7,
            "agent_states": {},
        }
        _store[session_id] = bucket
    return bucket


class ShortTermMemory:
    def __init__(self, session_id: str):
        self.session_id = session_id

    async def add(self, role: str, content: str, meta: dict = None):
        b = _bucket(self.session_id)
        b["history"].append({"role": role, "content": content, "meta": meta or {}})
        b["expires"] = time.time() + 86400 * 7  # refresh TTL on activity
        limit = settings.short_term_history_k * 2
        if len(b["history"]) > limit:
            b["history"] = b["history"][-limit:]

    async def get_recent(self, k: int = 20) -> list[dict]:
        return _bucket(self.session_id)["history"][-k:]

    async def get_context_string(self, k: int = 10) -> str:
        history = await self.get_recent(k)
        return "\n".join(f"{m['role'].upper()}: {m['content'][:500]}" for m in history)

    async def clear(self):
        _store.pop(self.session_id, None)

    async def set_agent_state(self, key: str, value: dict):
        b = _bucket(self.session_id)
        b["agent_states"][key] = {"value": value, "expires": time.time() + 3600}

    async def get_agent_state(self, key: str) -> Optional[dict]:
        b = _bucket(self.session_id)
        entry = b["agent_states"].get(key)
        if entry and time.time() < entry["expires"]:
            return entry["value"]
        return None
