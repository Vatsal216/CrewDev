"""
Embedder — tiered fallback, zero external service required.

Priority:
  1. VoyageAI  (best quality — set VOYAGE_API_KEY in .env)
  2. sentence-transformers  (good quality — local, no API key, no server)
  3. Zero vectors  (dev mode only — search won't rank results)
"""
from config import settings

_voyage_client = None
_st_model = None         # SentenceTransformer instance, or False if unavailable


def _get_voyage():
    global _voyage_client
    if _voyage_client is None and settings.voyage_api_key:
        import voyageai
        _voyage_client = voyageai.Client(api_key=settings.voyage_api_key)
    return _voyage_client


def _get_st():
    global _st_model
    if _st_model is None:
        try:
            from sentence_transformers import SentenceTransformer
            _st_model = SentenceTransformer("all-MiniLM-L6-v2")
        except ImportError:
            _st_model = False
    return _st_model if _st_model is not False else None


async def get_embeddings(texts: list[str]) -> list[list[float]]:
    # 1. VoyageAI (API key required)
    vc = _get_voyage()
    if vc:
        result = vc.embed(texts, model=settings.embed_model)
        return result.embeddings

    # 2. Local sentence-transformers (no API key, no server)
    st = _get_st()
    if st:
        vecs = st.encode(texts, convert_to_numpy=True)
        return [v.tolist() for v in vecs]

    # 3. Zero-vector fallback — install sentence-transformers for real results
    return [[0.0] * 384 for _ in texts]
