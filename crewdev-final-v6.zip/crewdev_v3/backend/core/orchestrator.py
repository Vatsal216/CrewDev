"""
MainOrchestrator — Plan → ReAct Loop → Validate → Synthesize

Each subtask runs a full ReAct (Reason + Act) loop:
  - Agent thinks about what to do
  - Calls a tool
  - Sees the result
  - Thinks again
  - Repeats until done or max_steps reached

Subagents can be spawned INSIDE the loop when the parent agent
decides it needs a specialist. Each subagent runs its OWN
independent ReAct loop (max_depth=2 to prevent infinite nesting).

Self-learning: after every task, lessons (what worked / what failed)
are stored in LongTermMemory and recalled by the Planner next time.
"""
import uuid
import json
import asyncio
from typing import Callable, Awaitable, Optional

from config import settings
from core.agent_factory import AgentFactory, AGENT_CONFIGS
from core.validator import OutputValidator
from core.harness import ProjectHarness
from core.token_tracker import TokenTracker
from core.llm.router import LLMRouter
from core.llm.types import ResolvedCall
from memory.short_term import ShortTermMemory
from memory.long_term import LongTermMemory
from tools.all_tools import (
    FileReadTool, FileWriteTool, FileListTool, FileDeleteTool,
    BashTool, WebSearchTool, VectorSearchTool, GitTool,
    SystemReadFileTool, SystemListDirTool, SystemWriteFileTool,
)

StreamCallback = Callable[[dict], Awaitable[None]]

MAX_REQUEST_TOKENS = getattr(settings, "max_request_tokens", 200_000)
PASS_THRESHOLD     = 0.7
MAX_STEPS          = 15      # ReAct loop hard limit per agent
SUBAGENT_MAX_STEPS = 8       # subagents get fewer steps
MAX_SUBAGENT_DEPTH = 2       # no subagents-of-subagents-of-subagents


# ─── Tool registry ─────────────────────────────────────────────────────────────

def _build_tools(project_id: str) -> dict:
    """Return all available tools keyed by name."""
    return {
        "read_file":        FileReadTool(project_id=project_id),
        "write_file":       FileWriteTool(project_id=project_id),
        "list_files":       FileListTool(project_id=project_id),
        "delete_file":      FileDeleteTool(project_id=project_id),
        "run_bash":         BashTool(project_id=project_id),
        "web_search":       WebSearchTool(project_id=project_id),
        "search_project":   VectorSearchTool(project_id=project_id),
        "git_info":         GitTool(project_id=project_id),
        "system_read_file": SystemReadFileTool(project_id=project_id),
        "system_list_dir":  SystemListDirTool(project_id=project_id),
        "system_write_file":SystemWriteFileTool(project_id=project_id),
    }


def _tool_descriptions() -> str:
    return """Available tools:
- read_file(path)              : Read file from project workspace (relative path)
- write_file(path, content)    : Write file to project workspace
- list_files(path=".")         : List files in project workspace directory
- delete_file(path)            : Delete file from project workspace
- run_bash(command)            : Run shell command in project workspace
- web_search(query)            : Search the web for information
- search_project(query)        : Semantic search over indexed project files
- git_info(command)            : Read-only git info (log, status, diff, branch)
- system_read_file(path)       : Read ANY file by absolute path (e.g. C:\\Users\\...\\file.py)
- system_list_dir(path)        : List ANY directory by absolute path
- system_write_file(path, content): Write ANY file by absolute path
- spawn_subagent(agent_type, task): Spawn a specialist subagent for a focused task
- done(result)                 : Signal task completion with final result"""


# ─── Data classes ──────────────────────────────────────────────────────────────

class SubTask:
    def __init__(self, id: str, description: str, agent_type: str,
                 expected_output: str, success_criteria: str,
                 depends_on: Optional[list] = None):
        self.id = id
        self.description = description
        self.agent_type = agent_type
        self.expected_output = expected_output
        self.success_criteria = success_criteria
        self.depends_on = depends_on or []


class Plan:
    def __init__(self, subtasks: list, reasoning: str):
        self.subtasks = subtasks
        self.reasoning = reasoning


# ─── ReAct step parser ─────────────────────────────────────────────────────────

def _parse_react_step(text: str) -> dict:
    """
    Parse LLM output for a ReAct step. Expects JSON like:
    {
      "thought": "I need to read the main file first",
      "action": "read_file",
      "args": {"path": "main.py"}
    }
    OR for completion:
    {
      "thought": "I have all the information needed",
      "action": "done",
      "args": {"result": "Here is my analysis..."}
    }
    """
    raw = (text or "").strip()
    # Try direct JSON
    try:
        return json.loads(raw)
    except Exception:
        pass
    # Try fenced
    import re
    fenced = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", raw, re.S | re.I)
    if fenced:
        try:
            return json.loads(fenced.group(1))
        except Exception:
            pass
    # Try extracting JSON object
    start, end = raw.find("{"), raw.rfind("}")
    if start >= 0 and end > start:
        try:
            return json.loads(raw[start:end + 1])
        except Exception:
            pass
    # Fallback: treat entire text as done result
    return {"thought": "Completing task", "action": "done", "args": {"result": raw}}


# ─── Main Orchestrator ─────────────────────────────────────────────────────────

class MainOrchestrator:

    def __init__(self, project_id: str, session_id: str, resolved: ResolvedCall):
        self.project_id = project_id
        self.session_id = session_id
        self.resolved   = resolved
        self.router     = LLMRouter()
        self.harness    = ProjectHarness(project_id)
        self.factory    = AgentFactory(project_id, self.harness)
        self.validator  = OutputValidator()
        self.tools      = _build_tools(project_id)
        self._short_mem = None
        self._long_mem  = None

    @property
    def short_mem(self) -> ShortTermMemory:
        if self._short_mem is None:
            self._short_mem = ShortTermMemory(self.session_id)
        return self._short_mem

    @property
    def long_mem(self) -> LongTermMemory:
        if self._long_mem is None:
            self._long_mem = LongTermMemory(self.project_id)
        return self._long_mem

    # ── Entry point ────────────────────────────────────────────────────────────

    async def process(
        self,
        user_message: str,
        stream_cb: Optional[StreamCallback] = None,
        skills_block: str = "",
        attachments_text: str = "",
        attachment_images=None,
    ) -> str:
        tracker = TokenTracker()

        if attachment_images:
            attachments_text = (attachments_text + f"\n[images attached: {len(attachment_images)}]").strip()
        if attachments_text:
            user_message = f"{attachments_text}\n\n{user_message}"

        async def emit(event: dict):
            if stream_cb:
                await stream_cb(event)

        await emit({"type": "status", "message": "Loading project context…"})

        context        = await self.harness.get_context()
        history        = await self.short_mem.get_context_string(k=settings.short_term_history_k)
        memory_snippets = await self.long_mem.search(user_message, k=5)
        lessons        = await self.long_mem.get_lessons(user_message, k=3)
        memory_str     = "\n".join(memory_snippets) if memory_snippets else ""

        await emit({"type": "status", "message": "Planning task decomposition…"})

        plan = await self._plan(
            user_message, context, history, memory_str, lessons, tracker, skills_block
        )
        await emit({"type": "plan", "subtasks": [
            {"id": t.id, "agent_type": t.agent_type,
             "description": t.description[:100], "depends_on": t.depends_on}
            for t in plan.subtasks
        ]})

        results: dict[str, str] = {}

        for subtask in plan.subtasks:
            if tracker.over_budget(MAX_REQUEST_TOKENS):
                await emit({"type": "budget_stop",
                            "message": f"Token budget reached. Stopping."})
                break

            upstream = self._gather_upstream(subtask, results)

            await emit({
                "type": "agent_start",
                "task_id": subtask.id,
                "agent_type": subtask.agent_type,
                "description": subtask.description[:150],
            })

            result, passed = await self._execute_react(
                subtask, context, user_message, upstream, emit, tracker
            )
            results[subtask.id] = result

            # Self-learning: store lesson about what worked or failed
            await self._store_lesson(
                user_message, subtask, result, passed
            )

            await emit({
                "type": "agent_done",
                "task_id": subtask.id,
                "agent_type": subtask.agent_type,
                "result_preview": str(result)[:200],
            })

        await emit({"type": "status", "message": "Synthesizing final response…"})

        final = await self._synthesize_streaming(
            user_message, results, context, history, emit, tracker
        )

        await self.short_mem.add("user", user_message)
        await self.short_mem.add("assistant", final)
        await self.long_mem.store(user_message, final, context)
        await self.harness.update(final, self.resolved)
        await emit({"type": "usage", **tracker.summary()})

        return final

    # ── ReAct execution loop ───────────────────────────────────────────────────

    async def _execute_react(
        self,
        subtask: SubTask,
        context: str,
        user_request: str,
        upstream: str,
        emit: Callable,
        tracker: TokenTracker,
        depth: int = 0,
        max_steps: int = MAX_STEPS,
    ) -> tuple[str, bool]:
        """
        Run a full ReAct loop for one subtask.
        Returns (result_str, passed_validation).
        """
        cfg         = AGENT_CONFIGS.get(subtask.agent_type, AGENT_CONFIGS["analyst"])
        allowed_tools = set(cfg.get("tools", list(self.tools.keys())))

        system = f"""You are a {cfg['role']}.
Goal: {cfg['goal']}
{cfg['backstory']}

Project context:
{context[:1500] if context else 'No context yet.'}

{upstream[:1000] if upstream else ''}

{_tool_descriptions()}

You work in a ReAct loop. Each step output ONLY valid JSON:
{{
  "thought": "your reasoning about what to do next",
  "action": "tool_name",
  "args": {{"arg1": "value1"}}
}}

When you have a complete answer, use:
{{
  "thought": "I have completed the task",
  "action": "done",
  "args": {{"result": "your full answer here"}}
}}

Rules:
- One action per step. No prose outside JSON.
- Use system_read_file / system_list_dir for absolute paths (e.g. C:\\Users\\...)
- Use read_file / list_files for relative paths inside the project workspace
- spawn_subagent only when you genuinely need a specialist (depth limit: {MAX_SUBAGENT_DEPTH})
- Max {max_steps} steps — be efficient"""

        messages = [
            {"role": "user", "content": f"TASK: {subtask.description}\n\nEXPECTED OUTPUT: {subtask.expected_output}"}
        ]

        step_history = []
        final_result = ""

        for step in range(max_steps):
            if tracker.over_budget(MAX_REQUEST_TOKENS):
                break

            # Get next action from LLM
            try:
                raw, usage = await self.router.acomplete(
                    messages,
                    self.resolved,
                    system=system,
                    max_tokens=1000,
                )
                tracker.add_usage(usage, agent=f"{subtask.agent_type}_react")
            except Exception as e:
                final_result = f"LLM error in ReAct step: {e}"
                break

            parsed = _parse_react_step(raw)
            thought = parsed.get("thought", "")
            action  = parsed.get("action", "done")
            args    = parsed.get("args", {})

            await emit({
                "type":       "react_step",
                "task_id":    subtask.id,
                "step":       step + 1,
                "agent_type": subtask.agent_type,
                "thought":    thought[:200],
                "action":     action,
            })

            step_history.append({"step": step + 1, "thought": thought, "action": action})

            # ── Handle: done ────────────────────────────────────────────────
            if action == "done":
                final_result = args.get("result", raw)
                break

            # ── Handle: spawn_subagent ──────────────────────────────────────
            if action == "spawn_subagent":
                if depth >= MAX_SUBAGENT_DEPTH:
                    tool_result = "ERROR: Max subagent depth reached. Complete the task yourself."
                else:
                    sub_type = args.get("agent_type", "analyst")
                    sub_task_desc = args.get("task", "Complete the delegated task")
                    sub_expected  = args.get("expected_output", "A complete, detailed answer")

                    await emit({
                        "type":           "subagent_start",
                        "parent_task_id": subtask.id,
                        "agent_type":     sub_type,
                        "description":    sub_task_desc[:150],
                        "depth":          depth + 1,
                    })

                    sub_subtask = SubTask(
                        id=f"{subtask.id}_sub_{step}",
                        description=sub_task_desc,
                        agent_type=sub_type,
                        expected_output=sub_expected,
                        success_criteria="",
                    )
                    sub_result, _ = await self._execute_react(
                        sub_subtask,
                        context,
                        sub_task_desc,
                        f"Parent task context:\n{subtask.description[:500]}",
                        emit,
                        tracker,
                        depth=depth + 1,
                        max_steps=SUBAGENT_MAX_STEPS,
                    )

                    await emit({
                        "type":           "subagent_done",
                        "parent_task_id": subtask.id,
                        "agent_type":     sub_type,
                        "depth":          depth + 1,
                        "result_preview": sub_result[:150],
                    })

                    tool_result = f"SUBAGENT ({sub_type}) RESULT:\n{sub_result}"

            # ── Handle: regular tool call ───────────────────────────────────
            else:
                tool_result = await self._call_tool(action, args, subtask.agent_type)

                await emit({
                    "type":        "tool_result",
                    "task_id":     subtask.id,
                    "tool":        action,
                    "result_preview": str(tool_result)[:150],
                })

            # Add tool result to conversation so LLM can reason about it
            messages.append({"role": "assistant", "content": raw})
            messages.append({
                "role": "user",
                "content": f"TOOL RESULT ({action}):\n{str(tool_result)[:3000]}\n\nContinue. Output JSON for next step."
            })

            # Trim messages to avoid context explosion (keep last 20 exchanges)
            if len(messages) > 42:
                messages = messages[:1] + messages[-40:]

        # If loop exhausted without done, use last tool result or step history
        if not final_result:
            final_result = (
                messages[-1]["content"][:2000]
                if len(messages) > 1
                else f"Task incomplete after {max_steps} steps."
            )

        # Validate the result
        verdict = await self.validator.evaluate(
            final_result,
            subtask.description,
            subtask.success_criteria,
            user_request,
            resolved=self.resolved,
        )

        await emit({
            "type":     "validation",
            "task_id":  subtask.id,
            "passed":   verdict.passed,
            "score":    round(verdict.score, 2),
            "feedback": verdict.feedback,
            "attempt":  1,
        })

        # If validation failed and we have budget, do one retry with feedback
        if not verdict.passed and verdict.score < PASS_THRESHOLD and not tracker.over_budget(MAX_REQUEST_TOKENS):
            await emit({"type": "retry", "task_id": subtask.id, "attempt": 2})

            retry_subtask = SubTask(
                id=subtask.id,
                description=f"{subtask.description}\n\nPREVIOUS ATTEMPT FEEDBACK:\n{verdict.feedback}\nFix these issues.",
                agent_type=subtask.agent_type,
                expected_output=subtask.expected_output,
                success_criteria=subtask.success_criteria,
            )
            final_result, _ = await self._execute_react(
                retry_subtask,
                context,
                user_request,
                f"Previous attempt result:\n{final_result[:1000]}",
                emit,
                tracker,
                depth=depth,
                max_steps=max_steps // 2,  # half steps on retry
            )
            return final_result, True  # treat retry as passed

        return final_result, verdict.passed or verdict.score >= PASS_THRESHOLD

    # ── Tool execution ─────────────────────────────────────────────────────────

    async def _call_tool(self, action: str, args: dict, agent_type: str) -> str:
        tool = self.tools.get(action)
        if not tool:
            return f"ERROR: Unknown tool '{action}'. Available: {', '.join(self.tools.keys())}"
        try:
            # All our tools are synchronous _run() methods — run in thread
            if action == "write_file" or action == "system_write_file":
                result = await asyncio.to_thread(tool._run, args.get("path", ""), args.get("content", ""))
            elif action == "run_bash":
                result = await asyncio.to_thread(tool._run, args.get("command", ""))
            elif action == "web_search":
                result = await asyncio.to_thread(tool._run, args.get("query", ""))
            elif action == "search_project":
                result = await asyncio.to_thread(tool._run, args.get("query", ""))
            elif action == "git_info":
                result = await asyncio.to_thread(tool._run, args.get("command", "log --oneline -10"))
            elif action in ("read_file", "system_read_file"):
                result = await asyncio.to_thread(tool._run, args.get("path", ""))
            elif action in ("list_files", "system_list_dir"):
                result = await asyncio.to_thread(tool._run, args.get("path", "."))
            elif action == "delete_file":
                result = await asyncio.to_thread(tool._run, args.get("path", ""))
            else:
                result = await asyncio.to_thread(tool._run, **args)
            return str(result)
        except Exception as e:
            return f"ERROR running {action}: {e}"

    # ── Self-learning ──────────────────────────────────────────────────────────

    async def _store_lesson(
        self, user_message: str, subtask: SubTask, result: str, passed: bool
    ):
        """Store a lesson about what worked or failed for future planning."""
        try:
            if passed:
                lesson = (
                    f"SUCCESS: For task type '{subtask.agent_type}' on request like "
                    f"'{user_message[:80]}', the approach worked. "
                    f"Result preview: {result[:100]}"
                )
            else:
                lesson = (
                    f"FAILURE: For task type '{subtask.agent_type}' on request like "
                    f"'{user_message[:80]}', the approach failed. "
                    f"Task was: {subtask.description[:100]}"
                )
            await self.long_mem.store_lesson(lesson)
        except Exception:
            pass  # non-critical

    # ── Planner ────────────────────────────────────────────────────────────────

    async def _plan(
        self,
        user_message: str,
        context: str,
        history: str,
        memory: str,
        lessons: list[str],
        tracker: TokenTracker,
        skills_block: str = "",
    ) -> Plan:
        lessons_str = "\n".join(f"- {l}" for l in lessons) if lessons else "No prior lessons yet."

        prompt = f"""You are an AI orchestrator. Decompose the user's request into subtasks.

PROJECT CONTEXT:
{context[:1000]}

CONVERSATION HISTORY:
{history[-1500:] if history else 'No history'}

RELEVANT MEMORIES:
{memory[:800] if memory else 'None'}

LESSONS FROM PAST TASKS (use these to pick better agents/approaches):
{lessons_str}

USER REQUEST:
{user_message}

Available agent types: coder, researcher, web_surfer, file_manager, analyst, tester, devops

IMPORTANT: Each agent now runs a self-contained ReAct loop with full tool access including:
- system_read_file / system_list_dir for absolute paths anywhere on the system
- spawn_subagent to delegate to a specialist

Return JSON only:
{{
  "reasoning": "why you chose these subtasks",
  "subtasks": [
    {{
      "id": "t1",
      "description": "Detailed task description with all context needed",
      "agent_type": "analyst",
      "expected_output": "What the agent should produce",
      "success_criteria": "How to judge if the output is good",
      "depends_on": []
    }}
  ]
}}

Guidelines:
- 1-3 subtasks max. Don't over-decompose.
- Simple questions (greetings, explanations): 1 subtask, analyst type.
- Use depends_on to chain tasks.
- For file system tasks outside workspace: agent will use system_read_file automatically."""

        if skills_block:
            prompt = f"{skills_block}\n\n{prompt}"

        text, usage = await self.router.acomplete(
            [{"role": "user", "content": prompt}],
            self.resolved,
            max_tokens=1500,
            response_format={"type": "json_object"},
        )
        tracker.add_usage(usage, "planner")

        try:
            data = json.loads(text)
            subtasks = [
                SubTask(
                    id=t.get("id", str(uuid.uuid4())[:8]),
                    description=t["description"],
                    agent_type=t.get("agent_type", "analyst"),
                    expected_output=t.get("expected_output", "Complete the task"),
                    success_criteria=t.get("success_criteria", ""),
                    depends_on=t.get("depends_on", []),
                )
                for t in data.get("subtasks", [])
            ]
            return Plan(subtasks=subtasks, reasoning=data.get("reasoning", ""))
        except Exception:
            inferred_type = self.factory.infer_agent_type(user_message)
            return Plan(
                subtasks=[SubTask(
                    id="t1",
                    description=user_message,
                    agent_type=inferred_type,
                    expected_output="Complete the user's request",
                    success_criteria="",
                )],
                reasoning="Fallback single-task plan",
            )

    # ── Helpers ────────────────────────────────────────────────────────────────

    def _gather_upstream(self, subtask: SubTask, results: dict) -> str:
        if subtask.depends_on:
            picked = {tid: results[tid] for tid in subtask.depends_on if tid in results}
        else:
            picked = {}
        if not picked:
            return ""
        parts = [f"OUTPUT FROM {tid}:\n{res[:2000]}" for tid, res in picked.items()]
        return "RESULTS FROM PREVIOUS AGENTS:\n\n" + "\n\n".join(parts)

    async def _synthesize_streaming(
        self,
        user_message: str,
        results: dict,
        context: str,
        history: str,
        emit: Callable,
        tracker: TokenTracker,
    ) -> str:
        if len(results) == 1:
            text = list(results.values())[0]
            await self._stream_text(text, emit)
            return text

        results_str = "\n\n".join(
            f"TASK {tid}:\n{res[:2000]}" for tid, res in results.items()
        )
        prompt = f"""Synthesize these agent outputs into a single coherent response.

USER REQUEST:
{user_message}

AGENT RESULTS:
{results_str}

Write a clear, well-formatted response. Use code blocks where relevant.
Be concise but complete. Don't repeat information."""

        full_text, usage = await self.router.astream(
            [{"role": "user", "content": prompt}],
            self.resolved,
            max_tokens=4000,
            emit=emit,
        )
        tracker.add_usage(usage, "synthesizer")
        return full_text

    async def _stream_text(self, text: str, emit: Callable, chunk: int = 24):
        for i in range(0, len(text), chunk):
            await emit({"type": "token", "text": text[i:i + chunk]})
            await asyncio.sleep(0.01)
