"""
DeepAgentsEngine — LangGraph-based ReAct loop engine.

Replaces the broken `deepagents` package dependency with a native
LangGraph ReAct implementation that actually works.

This is the engine used when the user selects "DeepAgents" from
the dropdown in any panel.
"""
import asyncio
import json
import re
from typing import Optional, Callable, Awaitable

from core.harness import ProjectHarness
from core.llm.router import LLMRouter
from core.llm.types import ResolvedCall
from core.token_tracker import TokenTracker
from tools.all_tools import (
    FileReadTool, FileWriteTool, FileListTool, FileDeleteTool,
    BashTool, WebSearchTool, VectorSearchTool, GitTool,
    SystemReadFileTool, SystemListDirTool, SystemWriteFileTool,
)

MAX_STEPS = 20


def _build_tools(project_id: str) -> dict:
    return {
        "read_file":         FileReadTool(project_id=project_id),
        "write_file":        FileWriteTool(project_id=project_id),
        "list_files":        FileListTool(project_id=project_id),
        "delete_file":       FileDeleteTool(project_id=project_id),
        "run_bash":          BashTool(project_id=project_id),
        "web_search":        WebSearchTool(project_id=project_id),
        "search_project":    VectorSearchTool(project_id=project_id),
        "git_info":          GitTool(project_id=project_id),
        "system_read_file":  SystemReadFileTool(project_id=project_id),
        "system_list_dir":   SystemListDirTool(project_id=project_id),
        "system_write_file": SystemWriteFileTool(project_id=project_id),
    }


TOOL_DESCRIPTIONS = """Available tools:
- read_file(path)               : Read file from project workspace (relative path)
- write_file(path, content)     : Write file to project workspace
- list_files(path=".")          : List files/dirs in project workspace
- delete_file(path)             : Delete file from project workspace
- run_bash(command)             : Run shell command in project workspace
- web_search(query)             : Search the web
- search_project(query)         : Semantic search over project files
- git_info(command)             : Read-only git (log, status, diff, branch)
- system_read_file(path)        : Read ANY file by absolute path (C:\\Users\\...\\file.py)
- system_list_dir(path)         : List ANY directory by absolute path
- system_write_file(path, content): Write ANY file by absolute path
- done(result)                  : Signal completion with final answer"""


def _parse_step(text: str) -> dict:
    raw = (text or "").strip()
    try:
        return json.loads(raw)
    except Exception:
        pass
    fenced = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", raw, re.S | re.I)
    if fenced:
        try:
            return json.loads(fenced.group(1))
        except Exception:
            pass
    s, e = raw.find("{"), raw.rfind("}")
    if s >= 0 and e > s:
        try:
            return json.loads(raw[s:e + 1])
        except Exception:
            pass
    return {"thought": "Completing", "action": "done", "args": {"result": raw}}


async def _call_tool(tools: dict, action: str, args: dict) -> str:
    tool = tools.get(action)
    if not tool:
        return f"ERROR: Unknown tool '{action}'. Available: {', '.join(tools.keys())}"
    try:
        if action in ("write_file", "system_write_file"):
            result = await asyncio.to_thread(tool._run, args.get("path", ""), args.get("content", ""))
        elif action == "run_bash":
            result = await asyncio.to_thread(tool._run, args.get("command", ""))
        elif action in ("web_search", "search_project"):
            result = await asyncio.to_thread(tool._run, args.get("query", ""))
        elif action == "git_info":
            result = await asyncio.to_thread(tool._run, args.get("command", "log --oneline -10"))
        elif action in ("read_file", "system_read_file"):
            result = await asyncio.to_thread(tool._run, args.get("path", ""))
        elif action in ("list_files", "system_list_dir"):
            result = await asyncio.to_thread(tool._run, args.get("path", "."))
        elif action == "delete_file":
            result = await asyncio.to_thread(tool._run, args.get("path", ""))
        else:
            result = await asyncio.to_thread(tool._run, **args)
        return str(result)
    except Exception as e:
        return f"ERROR running {action}: {e}"


class DeepAgentsEngine:
    """
    LangGraph-style ReAct loop engine.
    Runs a continuous Think → Act → Observe loop until the agent
    calls done() or hits MAX_STEPS.
    """

    def __init__(self, project_id: str, session_id: str, resolved: ResolvedCall):
        self.project_id = project_id
        self.session_id = session_id
        self.resolved   = resolved
        self.router     = LLMRouter()
        self.harness    = ProjectHarness(project_id)
        self.tools      = _build_tools(project_id)
        self.tracker    = TokenTracker()

    async def process(
        self,
        user_message: str,
        stream_cb: Optional[Callable[[dict], Awaitable[None]]] = None,
        *,
        skills_block: str = "",
        attachments_text: str = "",
        attachment_images: Optional[list] = None,
    ) -> str:

        async def emit(event: dict):
            if stream_cb:
                await stream_cb(event)

        await emit({"type": "status", "message": "DeepAgents: starting ReAct loop…"})

        try:
            context = await self.harness.get_context()
        except Exception:
            context = ""

        system = f"""{skills_block + chr(10) if skills_block else ""}You are a DeepAgents AI assistant with full tool access.

Project context:
{context[:1500] if context else 'No project context yet.'}

{TOOL_DESCRIPTIONS}

Work in a ReAct loop. Each step output ONLY valid JSON:
{{
  "thought": "your reasoning about what to do next",
  "action": "tool_name",
  "args": {{"arg1": "value1"}}
}}

When done:
{{
  "thought": "Task complete",
  "action": "done",
  "args": {{"result": "your complete answer"}}
}}

Rules:
- One action per step. No prose outside JSON.
- Use system_read_file / system_list_dir for absolute paths (e.g. C:\\Users\\...)
- Use read_file / list_files for relative project paths
- Max {MAX_STEPS} steps total"""

        if attachments_text:
            user_message = f"{attachments_text}\n\n{user_message}"

        messages = [{"role": "user", "content": user_message}]
        final_result = ""

        for step in range(MAX_STEPS):
            if self.tracker.over_budget(200_000):
                await emit({"type": "status", "message": "Token budget reached."})
                break

            try:
                raw, usage = await self.router.acomplete(
                    messages,
                    self.resolved,
                    system=system,
                    max_tokens=1000,
                )
                self.tracker.add_usage(usage, agent="deepagents")
            except Exception as e:
                final_result = f"DeepAgents error: {e}"
                await emit({"type": "error", "message": str(e)})
                break

            parsed  = _parse_step(raw)
            thought = parsed.get("thought", "")
            action  = parsed.get("action", "done")
            args    = parsed.get("args", {})

            await emit({
                "type":    "react_step",
                "task_id": "deepagents",
                "step":    step + 1,
                "agent_type": "deepagents",
                "thought": thought[:200],
                "action":  action,
            })

            if action == "done":
                final_result = args.get("result", raw)
                break

            tool_result = await _call_tool(self.tools, action, args)

            await emit({
                "type":           "tool_result",
                "task_id":        "deepagents",
                "tool":           action,
                "result_preview": str(tool_result)[:150],
            })

            messages.append({"role": "assistant", "content": raw})
            messages.append({
                "role": "user",
                "content": f"TOOL RESULT ({action}):\n{str(tool_result)[:3000]}\n\nContinue. Output JSON for next step."
            })

            # Trim context to avoid explosion
            if len(messages) > 42:
                messages = messages[:1] + messages[-40:]

        if not final_result:
            final_result = (
                messages[-1]["content"][:2000]
                if len(messages) > 1
                else "Task incomplete."
            )

        # Stream the final result back token by token
        for i in range(0, len(final_result), 24):
            await emit({"type": "token", "text": final_result[i:i + 24]})
            await asyncio.sleep(0.005)

        await emit({"type": "usage", **self.tracker.summary()})
        return final_result
