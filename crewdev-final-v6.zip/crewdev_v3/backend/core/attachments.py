import io
import os
import base64

TEXT_EXTS = {".txt", ".md", ".py", ".js", ".ts", ".tsx", ".jsx", ".json", ".csv",
             ".yaml", ".yml", ".html", ".css", ".sh", ".go", ".rs", ".java", ".rb",
             ".toml", ".xml", ".log"}
IMAGE_MIME = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
              ".gif": "image/gif", ".webp": "image/webp"}


def extract(filename: str, data: bytes, max_chars: int = 20000) -> dict:
    ext = os.path.splitext(filename or "")[1].lower()
    if ext in IMAGE_MIME:
        b64 = base64.b64encode(data).decode()
        return {"name": filename, "kind": "image",
                "data_url": f"data:{IMAGE_MIME[ext]};base64,{b64}",
                "mime": IMAGE_MIME[ext], "b64": b64}
    if ext == ".pdf":
        try:
            import pdfplumber
            parts = []
            with pdfplumber.open(io.BytesIO(data)) as pdf:
                for page in pdf.pages:
                    parts.append(page.extract_text() or "")
            return {"name": filename, "kind": "text", "text": "\n".join(parts)[:max_chars]}
        except Exception:
            return {"name": filename, "kind": "text", "text": f"[could not read PDF: {filename}]"}
    if ext in TEXT_EXTS or ext == "":
        return {"name": filename, "kind": "text", "text": data.decode("utf-8", "replace")[:max_chars]}
    return {"name": filename, "kind": "text", "text": f"[unsupported file type: {filename}]"}


def _image_block_for_provider(data_url: str, mime: str, b64: str, model: str) -> dict:
    """
    Build the correct image content block for the active provider.

    - OpenAI / Azure / LiteLLM default: image_url with data URI
    - Anthropic: image with source.type=base64
    - Ollama: image_url (best effort — model-dependent)

    The model string comes from ResolvedCall.model which is prefixed by provider:
      anthropic/claude-... → Anthropic
      azure/gpt-4o        → Azure (OpenAI-compat)
      openai/gpt-4o       → OpenAI
      ollama_chat/...     → Ollama
    """
    m = (model or "").lower()
    if m.startswith("anthropic/"):
        return {
            "type": "image",
            "source": {
                "type": "base64",
                "media_type": mime,
                "data": b64,
            }
        }
    # OpenAI, Azure, Ollama, others — use image_url with data URI
    return {
        "type": "image_url",
        "image_url": {"url": data_url},
    }


def build_user_content(
    user_message: str,
    attachments_text: str = "",
    attachment_images=None,
    model: str = "",
):
    """
    Build the user content block for the LLM.

    attachment_images: list of dicts with keys data_url, mime, b64
    (new format from extract()), or plain data_url strings (legacy).
    model: ResolvedCall.model — used to choose image block format per provider.
    """
    text = f"{attachments_text}\n\n{user_message}" if attachments_text else user_message

    if not attachment_images:
        return text

    blocks = [{"type": "text", "text": text}]
    for img in attachment_images:
        if isinstance(img, dict):
            data_url = img.get("data_url", "")
            mime = img.get("mime", "image/jpeg")
            b64 = img.get("b64", "")
            if not b64 and data_url.startswith("data:"):
                # extract b64 from data URI
                try:
                    b64 = data_url.split(",", 1)[1]
                except IndexError:
                    b64 = ""
        else:
            # legacy: plain data_url string
            data_url = img
            mime = "image/jpeg"
            try:
                b64 = data_url.split(",", 1)[1]
            except (IndexError, AttributeError):
                b64 = ""

        blocks.append(_image_block_for_provider(data_url, mime, b64, model))

    return blocks
