from typing import Awaitable, Callable, Optional
import asyncio

import litellm

# Disable litellm's internal client caching to prevent "client has been closed" errors
# Each request gets a fresh httpx client
litellm.disable_aiohttp_transport = True

from core.llm.types import ResolvedCall, Usage, LLMError

EmitCallback = Callable[[dict], Awaitable[None]]

_CLOSED_CLIENT_PHRASES = (
    "client has been closed",
    "client is closed",
    "connection closed",
    "event loop is closed",
)

def _classify(exc: Exception) -> LLMError:
    name = type(exc).__name__.lower()
    msg = str(exc) or name
    msg_lower = msg.lower()

    if any(phrase in msg_lower for phrase in _CLOSED_CLIENT_PHRASES):
        return LLMError("connection", "LLM client connection was closed. Please retry.")
    if "authentication" in name or "permission" in name or "auth" in name:
        return LLMError("auth", "Authentication failed — check the API key in Settings.")
    if "notfound" in name or "not_found" in name:
        return LLMError("model_not_found", msg)
    if "ratelimit" in name or "rate_limit" in name:
        return LLMError("rate_limit", msg)
    if "connection" in name or "timeout" in name or "apiconnection" in name:
        return LLMError("connection", msg)
    return LLMError("provider_error", "The model provider returned an error.")


def _safe_cost(model: str, usage: Usage, response=None) -> float:
    try:
        if response is not None:
            return float(litellm.completion_cost(completion_response=response) or 0.0)
        prompt_cost, completion_cost = litellm.cost_per_token(
            model=model,
            prompt_tokens=usage.input_tokens,
            completion_tokens=usage.output_tokens,
        )
        return float((prompt_cost or 0.0) + (completion_cost or 0.0))
    except Exception:
        return 0.0


def _with_system(messages: list[dict], system: Optional[str]) -> list[dict]:
    if system:
        return [{"role": "system", "content": system}] + list(messages)
    return list(messages)


def _supports_json_mode(model: str) -> bool:
    if model.startswith("ollama"):
        return False
    return True


async def _acompletion_with_retry(max_retries: int = 2, **kwargs):
    """Call litellm.acompletion with retry on closed-client errors."""
    last_exc = None
    for attempt in range(max_retries + 1):
        try:
            return await litellm.acompletion(**kwargs)
        except Exception as e:
            msg = str(e).lower()
            if any(phrase in msg for phrase in _CLOSED_CLIENT_PHRASES):
                last_exc = e
                if attempt < max_retries:
                    await asyncio.sleep(0.2 * (attempt + 1))
                    continue
            raise e
    raise last_exc


class LLMRouter:
    """One streaming/blocking entry point over all providers via LiteLLM."""

    async def astream(
        self,
        messages: list[dict],
        resolved: ResolvedCall,
        *,
        system: Optional[str] = None,
        max_tokens: int = 4000,
        temperature: float = 0.7,
        response_format: Optional[dict] = None,
        emit: Optional[EmitCallback] = None,
    ) -> tuple[str, Usage]:
        msgs = _with_system(messages, system)
        extra = (
            {"response_format": response_format}
            if response_format and _supports_json_mode(resolved.model)
            else {}
        )
        usage = Usage(model=resolved.model)
        parts: list[str] = []

        try:
            response = await _acompletion_with_retry(
                model=resolved.model,
                messages=msgs,
                stream=True,
                max_tokens=max_tokens,
                temperature=temperature,
                # NOTE: stream_options removed — causes issues with some providers/versions
                **extra,
                **resolved.kwargs,
            )
            chunks = response.__aiter__()
        except Exception as e:
            raise _classify(e)

        while True:
            try:
                chunk = await chunks.__anext__()
            except StopAsyncIteration:
                break
            except Exception as e:
                # If client closes mid-stream, return what we have rather than crashing
                msg = str(e).lower()
                if any(phrase in msg for phrase in _CLOSED_CLIENT_PHRASES):
                    break
                raise _classify(e)

            choices = getattr(chunk, "choices", None)
            delta = choices[0].delta.content if choices else None
            if delta:
                parts.append(delta)
                if emit:
                    await emit({"type": "token", "text": delta})
            chunk_usage = getattr(chunk, "usage", None)
            if chunk_usage:
                usage.input_tokens = getattr(chunk_usage, "prompt_tokens", 0) or 0
                usage.output_tokens = getattr(chunk_usage, "completion_tokens", 0) or 0

        usage.cost_usd = _safe_cost(resolved.model, usage)
        return "".join(parts), usage

    async def acomplete(
        self,
        messages: list[dict],
        resolved: ResolvedCall,
        *,
        system: Optional[str] = None,
        max_tokens: int = 1500,
        response_format: Optional[dict] = None,
    ) -> tuple[str, Usage]:
        msgs = _with_system(messages, system)
        extra = (
            {"response_format": response_format}
            if response_format and _supports_json_mode(resolved.model)
            else {}
        )
        try:
            response = await _acompletion_with_retry(
                model=resolved.model,
                messages=msgs,
                stream=False,
                max_tokens=max_tokens,
                **extra,
                **resolved.kwargs,
            )
        except Exception as e:
            raise _classify(e)

        text = response.choices[0].message.content or ""
        u = getattr(response, "usage", None)
        usage = Usage(
            model=resolved.model,
            input_tokens=getattr(u, "prompt_tokens", 0) or 0 if u else 0,
            output_tokens=getattr(u, "completion_tokens", 0) or 0 if u else 0,
        )
        usage.cost_usd = _safe_cost(resolved.model, usage, response=response)
        return text, usage
