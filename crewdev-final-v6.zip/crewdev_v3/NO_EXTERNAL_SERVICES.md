# CrewDev — No External Services Required

This version removes all mandatory external service dependencies.
Everything runs with a single `pip install -r requirements.txt`.

---

## What Changed vs. Original

| Component | Before | After |
|-----------|--------|-------|
| Short-term memory | Redis server | Pure Python `dict` (in-process, same TTL logic) |
| Database | PostgreSQL | **SQLite** (`crewdev.db`, auto-created) |
| DB driver | `asyncpg` | `aiosqlite` (bundled with Python) |
| Migrations | Alembic | `Base.metadata.create_all` + inline `ALTER TABLE` |
| Embeddings (no key) | Zero vectors | `sentence-transformers` local fallback |
| Embeddings (with key) | VoyageAI | VoyageAI (unchanged) |

ChromaDB is kept — it is a pure Python library, no server needed.

---

## Bugs Fixed in This Release

| # | File | Bug | Fix |
|---|------|-----|-----|
| 1 | `db/models.py` | WAL PRAGMA silently failed — `dbapi_conn.execute()` not supported by aiosqlite | Use `cursor = dbapi_conn.cursor(); cursor.execute(...); cursor.close()` |
| 2 | `core/llm/router.py` | `response_format=json_object` crashes Ollama (unsupported parameter) | Strip for all `ollama*` models via `_supports_json_mode()` guard |
| 3 | `tools/all_tools.py` | `asyncio.run()` inside running loop (worker thread) → RuntimeError | `_sync_embeddings()` helper with thread-pool fallback |
| 4 | `tools/all_tools.py` | WebSurferTool crashed if `ANTHROPIC_API_KEY` not set | Guard + graceful httpx fallback |
| 5 | `tools/all_tools.py` | `VectorSearchInput` class definition was corrupted | Rewrote file cleanly |
| 6 | `projects/manager.py` | `ProjectIndexer.search()` had same asyncio.run bug | Removed dead method (never called) |

---

## Ollama — Local vs. Cloud

Add an Ollama provider in **Settings → Add provider → Ollama**:

| Mode | Base URL | API Key |
|------|----------|---------|
| Local | `http://localhost:11434` | *(leave blank)* |
| Cloud | `https://ollama.com` | `ollama_...` *(required)* |

The key is stored Fernet-encrypted in `crewdev.db`.

Or pre-configure via `.env`:
```
OLLAMA_BASE_URL=https://ollama.com
OLLAMA_API_KEY=ollama_...
```

---

## APP_SECRET — Keep This Safe

If `APP_SECRET` is not set in `.env`, a random key is auto-generated and
saved to `backend/.app_secret`. **Do not delete this file.** If it is lost,
all provider API keys stored in `crewdev.db` become permanently unreadable.

Best practice: generate and set it explicitly:
```bash
python -c "import secrets; print(secrets.token_urlsafe(32))"
# add APP_SECRET=<output> to backend/.env
```

---

## To Start (no Docker needed)

```bash
cd backend
cp .env.example .env        # edit to add your API key(s)
pip install -r requirements.txt
uvicorn main:app --reload
```

```bash
cd frontend
npm install
npm run dev
```

Or use `scripts/start.sh` to start both together.

---

## Optional Upgrades

| Feature | How |
|---------|-----|
| Better embeddings | Add `VOYAGE_API_KEY=pa-...` to `.env` |
| Web search | Add `TAVILY_API_KEY=tvly-...` to `.env` |
| AG2 WebSurfer | `pip install ag2[crawl4ai]` + `ANTHROPIC_API_KEY` set |
| Production DB | `DATABASE_URL=postgresql+asyncpg://...` + `pip install asyncpg` |
