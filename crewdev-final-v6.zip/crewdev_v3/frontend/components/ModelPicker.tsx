'use client'
import { useEffect, useRef, useState } from 'react'
import { ChevronDown, Check } from 'lucide-react'
import { useStore } from '@/lib/store'
import { api } from '@/lib/api'

interface ModelPickerProps {
  providerId: string | null
  model: string | null
  onChange: (providerId: string, model: string) => void
}

export default function ModelPicker({ providerId, model, onChange }: ModelPickerProps) {
  const { providers, setProviders } = useStore()
  const [open, setOpen] = useState(false)
  const [modelsByProvider, setModelsByProvider] = useState<Record<string, string[]>>({})
  // Per-provider custom model text input (for Azure and manual entry)
  const [customInput, setCustomInput] = useState<Record<string, string>>({})
  const dropdownRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (providers.length === 0) {
      api.providers.list().then(setProviders).catch(() => {})
    }
  }, [providers.length, setProviders])

  // Fetch model lists when dropdown opens
  useEffect(() => {
    if (!open) return
    const enabled = providers.filter(p => p.enabled)
    enabled.forEach(p => {
      if (modelsByProvider[p.id] !== undefined) return   // already fetched
      api.providers.models(p.id)
        .then(r => setModelsByProvider(prev => ({ ...prev, [p.id]: r.models })))
        .catch(() => setModelsByProvider(prev => ({ ...prev, [p.id]: [] })))
    })
  }, [open, providers])

  // Close on outside click
  useEffect(() => {
    if (!open) return
    function handleClick(e: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClick)
    return () => document.removeEventListener('mousedown', handleClick)
  }, [open])

  const current = providers.find(p => p.id === providerId)
  const label = model
    ? `${current?.label ?? ''}: ${model}`
    : 'Select model'

  function selectModel(pid: string, m: string) {
    if (!m.trim()) return
    onChange(pid, m.trim())
    setOpen(false)
  }

  return (
    <div style={{ position: 'relative' }} ref={dropdownRef}>
      <button
        onClick={() => setOpen(o => !o)}
        style={{
          display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 11,
          color: 'var(--text-secondary)', background: 'var(--bg-tertiary)',
          padding: '3px 10px', borderRadius: 99, border: '0.5px solid var(--border)',
          cursor: 'pointer', maxWidth: 260, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
        }}
      >
        <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {label}
        </span>
        <ChevronDown size={12} style={{ flexShrink: 0 }} />
      </button>

      {open && (
        <div style={{
          position: 'absolute', top: '110%', right: 0, zIndex: 50, minWidth: 260,
          background: 'var(--bg-secondary)', border: '0.5px solid var(--border-strong)',
          borderRadius: 10, padding: 6, maxHeight: 360, overflowY: 'auto',
          boxShadow: '0 8px 30px rgba(0,0,0,0.28)',
        }}>

          {providers.filter(p => p.enabled).length === 0 && (
            <div style={{ fontSize: 12, color: 'var(--text-muted)', padding: '8px 10px' }}>
              No providers. Add one in Settings.
            </div>
          )}

          {providers.filter(p => p.enabled).map(p => {
            const models = modelsByProvider[p.id]      // undefined = still loading
            const loading = models === undefined
            const isAzure = p.provider === 'azure'
            // Ollama fallback: if fetch returned empty, also show custom input
            const showCustomInput = isAzure || (p.provider === 'ollama' && models?.length === 0)
            const customVal = customInput[p.id] ?? ''

            return (
              <div key={p.id} style={{ marginBottom: 6 }}>
                {/* Provider header */}
                <div style={{
                  fontSize: 10, color: 'var(--text-muted)', padding: '6px 8px 3px',
                  textTransform: 'uppercase', letterSpacing: '0.04em',
                  display: 'flex', alignItems: 'center', gap: 6,
                }}>
                  {p.label}
                  {p.is_default && (
                    <span style={{ fontSize: 9, color: 'var(--brand-light)', textTransform: 'lowercase' }}>
                      default
                    </span>
                  )}
                  {loading && (
                    <span style={{ fontSize: 9, color: 'var(--text-muted)', textTransform: 'lowercase' }}>
                      loading…
                    </span>
                  )}
                </div>

                {/* Azure hint */}
                {isAzure && (
                  <div style={{
                    fontSize: 10, color: 'var(--text-muted)', padding: '2px 8px 6px',
                    lineHeight: 1.4,
                  }}>
                    Type your Azure deployment name below, or pick a suggestion.
                  </div>
                )}

                {/* Curated / fetched model list */}
                {!loading && (models ?? []).map(m => (
                  <button
                    key={`${p.id}:${m}`}
                    onClick={() => selectModel(p.id, m)}
                    style={{
                      display: 'flex', width: '100%', textAlign: 'left', fontSize: 12,
                      padding: '6px 8px', borderRadius: 6, border: 'none', cursor: 'pointer',
                      background: (p.id === providerId && m === model)
                        ? 'rgba(217,119,87,0.15)' : 'transparent',
                      color: 'var(--text-primary)',
                      alignItems: 'center', gap: 6,
                    }}
                  >
                    <span style={{ flex: 1 }}>{m}</span>
                    {p.id === providerId && m === model && (
                      <Check size={11} style={{ color: 'var(--brand-light)', flexShrink: 0 }} />
                    )}
                  </button>
                ))}

                {/* Fallback message for Ollama when server unreachable */}
                {!loading && !showCustomInput && (models ?? []).length === 0 && (
                  <div style={{ fontSize: 11, color: 'var(--text-muted)', padding: '3px 8px' }}>
                    No models returned. Is Ollama running?
                  </div>
                )}

                {/* ── Custom model text entry ──────────────────────────────── */}
                {/* Shown for Azure always, and for Ollama when model list is empty */}
                {showCustomInput && (
                  <div style={{ padding: '4px 8px 2px' }}>
                    {isAzure && (models ?? []).length > 0 && (
                      <div style={{ fontSize: 10, color: 'var(--text-muted)', marginBottom: 4 }}>
                        Or enter a custom deployment name:
                      </div>
                    )}
                    {!isAzure && (
                      <div style={{ fontSize: 10, color: 'var(--text-muted)', marginBottom: 4 }}>
                        Ollama server unreachable — enter model name manually:
                      </div>
                    )}
                    <div style={{ display: 'flex', gap: 6 }}>
                      <input
                        placeholder={isAzure ? 'e.g. gpt-4o (your deployment name)' : 'e.g. llama3'}
                        value={customVal}
                        onChange={e => setCustomInput(prev => ({ ...prev, [p.id]: e.target.value }))}
                        onKeyDown={e => {
                          if (e.key === 'Enter' && customVal.trim()) {
                            selectModel(p.id, customVal)
                          }
                        }}
                        style={{
                          flex: 1, fontSize: 11, padding: '5px 7px', borderRadius: 6,
                          background: 'var(--bg-primary)', color: 'var(--text-primary)',
                          border: '0.5px solid var(--border)', outline: 'none',
                        }}
                        autoFocus={isAzure && (models ?? []).length === 0}
                      />
                      <button
                        onClick={() => { if (customVal.trim()) selectModel(p.id, customVal) }}
                        disabled={!customVal.trim()}
                        style={{
                          fontSize: 11, padding: '5px 9px', borderRadius: 6, border: 'none',
                          background: customVal.trim() ? 'var(--brand-dark)' : 'var(--bg-tertiary)',
                          color: customVal.trim() ? 'white' : 'var(--text-muted)',
                          cursor: customVal.trim() ? 'pointer' : 'default',
                        }}
                      >
                        Use
                      </button>
                    </div>
                  </div>
                )}

                {/* Divider between providers */}
                {providers.filter(p2 => p2.enabled).indexOf(p) <
                  providers.filter(p2 => p2.enabled).length - 1 && (
                  <div style={{ height: 1, background: 'var(--border)', margin: '6px 4px 2px' }} />
                )}
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
