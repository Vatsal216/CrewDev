'use client'
import { useState } from 'react'
import { Folder, FolderOpen, FileCode, ChevronRight, ChevronDown, X, Loader2 } from 'lucide-react'
import { FileNode } from '@/lib/store'
import { api } from '@/lib/api'

const EXT_COLORS: Record<string, string> = {
  '.py': '#3B8BD4', '.ts': '#3B8BD4', '.tsx': '#1D9E75',
  '.js': '#BA7517', '.jsx': '#BA7517', '.json': '#D85A30',
  '.md': '#D97757', '.yml': '#993556', '.yaml': '#993556',
  '.css': '#D4537E', '.html': '#D85A30', '.sh': '#1D9E75',
}

// ── File Viewer Modal ──────────────────────────────────────────
interface ViewerProps {
  projectId: string
  path: string
  onClose: () => void
}

function FileViewer({ projectId, path, onClose }: ViewerProps) {
  const [content, setContent] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Load on mount
  useState(() => {
    api.projects.fileContent(projectId, path)
      .then(r => { setContent(r.content); setLoading(false) })
      .catch(e => { setError(e.message || 'Failed to read file'); setLoading(false) })
  })

  const ext = path.split('.').pop()?.toLowerCase() || ''
  const isMarkdown = ext === 'md'

  return (
    <div
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, zIndex: 200,
        background: 'rgba(0,0,0,0.6)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{
          width: 'min(900px, 92vw)', maxHeight: '85vh',
          background: 'var(--bg-primary)', border: '0.5px solid var(--border-strong)',
          borderRadius: 12, display: 'flex', flexDirection: 'column', overflow: 'hidden',
          boxShadow: '0 20px 60px rgba(0,0,0,0.4)',
        }}
      >
        {/* Header */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: 10, padding: '11px 16px',
          borderBottom: '0.5px solid var(--border)', flexShrink: 0,
        }}>
          <FileCode size={14} style={{ color: EXT_COLORS[`.${ext}`] || 'var(--text-muted)', flexShrink: 0 }} />
          <span style={{ fontSize: 12, color: 'var(--text-secondary)', fontFamily: 'monospace', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {path}
          </span>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', padding: 4, flexShrink: 0 }}>
            <X size={16} />
          </button>
        </div>

        {/* Content */}
        <div style={{ flex: 1, overflowY: 'auto', padding: 16 }}>
          {loading && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: 'var(--text-muted)', fontSize: 13 }}>
              <Loader2 size={14} style={{ animation: 'spin 1s linear infinite' }} /> Loading…
            </div>
          )}
          {error && (
            <div style={{ color: 'var(--red)', fontSize: 13 }}>Error: {error}</div>
          )}
          {content !== null && !loading && (
            <pre style={{
              margin: 0, fontSize: 12, lineHeight: 1.65,
              color: 'var(--text-primary)', fontFamily: "'JetBrains Mono', 'Fira Code', monospace",
              whiteSpace: 'pre-wrap', wordBreak: 'break-word',
            }}>
              {content}
            </pre>
          )}
        </div>
      </div>
      <style>{`@keyframes spin { from { transform: rotate(0deg) } to { transform: rotate(360deg) } }`}</style>
    </div>
  )
}

// ── File Tree Item ─────────────────────────────────────────────
interface FileItemProps {
  node: FileNode
  depth?: number
  projectId: string
  onOpen: (path: string) => void
}

function FileItem({ node, depth = 0, projectId, onOpen }: FileItemProps) {
  const [expanded, setExpanded] = useState(depth < 2)
  const indent = depth * 14 + 10

  if (node.type === 'dir') {
    return (
      <div>
        <div
          onClick={() => setExpanded(!expanded)}
          style={{
            display: 'flex', alignItems: 'center', gap: 5,
            padding: '4px 10px', paddingLeft: indent,
            cursor: 'pointer', fontSize: 12, color: 'var(--text-secondary)',
          }}
          onMouseEnter={e => (e.currentTarget.style.background = 'var(--bg-hover)')}
          onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
        >
          <span style={{ color: 'var(--text-muted)', flexShrink: 0 }}>
            {expanded ? <ChevronDown size={11} /> : <ChevronRight size={11} />}
          </span>
          {expanded
            ? <FolderOpen size={13} style={{ color: '#BA7517', flexShrink: 0 }} />
            : <Folder size={13} style={{ color: '#BA7517', flexShrink: 0 }} />
          }
          <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{node.name}</span>
        </div>
        {expanded && node.children?.map(child => (
          <FileItem key={child.path} node={child} depth={depth + 1} projectId={projectId} onOpen={onOpen} />
        ))}
      </div>
    )
  }

  const ext = node.extension || ''
  const color = EXT_COLORS[ext] || 'var(--text-muted)'

  return (
    <div
      onClick={() => onOpen(node.path)}
      title={`Click to view ${node.name}`}
      style={{
        display: 'flex', alignItems: 'center', gap: 5,
        padding: '3px 10px', paddingLeft: indent + 16,
        cursor: 'pointer', fontSize: 11, color: 'var(--text-muted)',
        borderRadius: 4, margin: '0 4px',
      }}
      onMouseEnter={e => {
        e.currentTarget.style.background = 'var(--bg-hover)'
        e.currentTarget.style.color = 'var(--text-secondary)'
      }}
      onMouseLeave={e => {
        e.currentTarget.style.background = 'transparent'
        e.currentTarget.style.color = 'var(--text-muted)'
      }}
    >
      <FileCode size={12} style={{ color, flexShrink: 0 }} />
      <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1 }}>
        {node.name}
      </span>
      {node.size !== undefined && (
        <span style={{ flexShrink: 0, fontSize: 10, color: 'var(--text-muted)' }}>
          {node.size < 1024 ? `${node.size}b` : `${(node.size / 1024).toFixed(1)}k`}
        </span>
      )}
    </div>
  )
}

// ── FileExplorer root ──────────────────────────────────────────
interface FileExplorerProps {
  tree: FileNode[]
  projectId: string
}

export default function FileExplorer({ tree, projectId }: FileExplorerProps) {
  const [viewerPath, setViewerPath] = useState<string | null>(null)

  if (!tree.length) {
    return (
      <div style={{ padding: '16px 14px', fontSize: 12, color: 'var(--text-muted)', textAlign: 'center' }}>
        No files yet.<br />Upload files or ask the agent to create some.
      </div>
    )
  }

  return (
    <>
      <div>
        {tree.map(node => (
          <FileItem
            key={node.path}
            node={node}
            projectId={projectId}
            onOpen={path => setViewerPath(path)}
          />
        ))}
      </div>
      {viewerPath && (
        <FileViewer
          projectId={projectId}
          path={viewerPath}
          onClose={() => setViewerPath(null)}
        />
      )}
    </>
  )
}
