'use client'
import { useEffect, useState } from 'react'
import { X, Plus, Trash2, CheckCircle2, XCircle, Loader2 } from 'lucide-react'
import { useStore, Provider, Skill } from '@/lib/store'
import { api } from '@/lib/api'
import { getSttMode, setSttMode, SttMode } from '@/lib/voice'

type ProviderField = {
  key: string
  label: string
  placeholder?: string
  helper?: string
  secret?: boolean
}

const PROVIDER_FIELDS: Record<string, ProviderField[]> = {
  anthropic: [
    { key: 'api_key', label: 'API Key', placeholder: 'sk-ant-...', secret: true },
  ],
  openai: [
    { key: 'api_key', label: 'API Key', placeholder: 'sk-...', secret: true },
    { key: 'api_base', label: 'Base URL', placeholder: 'Optional, e.g. https://api.openai.com/v1' },
    { key: 'organization', label: 'Organization', placeholder: 'Optional' },
  ],
  azure: [
    { key: 'api_key', label: 'API Key', placeholder: 'Azure OpenAI key', secret: true },
    { key: 'api_base', label: 'Endpoint', placeholder: 'https://<resource>.openai.azure.com' },
    { key: 'api_version', label: 'API Version', placeholder: '2024-02-15-preview' },
    {
      key: 'default_deployment',
      label: 'Default deployment name',
      placeholder: 'e.g. gpt-4o  (the name you gave your deployment in Azure portal)',
      helper: 'This is your Azure deployment name, not the model name. Set as the default model after saving.',
    },
  ],
  ollama: [
    {
      key: 'api_base',
      label: 'Base URL',
      placeholder: 'http://localhost:11434',
      helper: 'Local: http://localhost:11434   |   Cloud: https://ollama.com',
    },
    {
      key: 'api_key',
      label: 'API Key',
      placeholder: 'Required for Ollama Cloud — leave blank for local',
      helper: 'Only needed when Base URL is https://ollama.com',
      secret: true,
    },
  ],
}

export default function SettingsModal({ onClose }: { onClose: () => void }) {
  const { providers, setProviders, defaultModel, setDefaultModel, skills, setSkills } = useStore()
  const [adding, setAdding] = useState(false)
  const [newProvider, setNewProvider] = useState('openai')
  const [newLabel, setNewLabel] = useState('')
  const [newConfig, setNewConfig] = useState<Record<string, string>>({})
  const [saveError, setSaveError] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [testResult, setTestResult] = useState<Record<string, { ok: boolean; message: string }>>({})
  const [testingId, setTestingId] = useState<string | null>(null)
  const [sttMode, setMode] = useState<SttMode>('browser')

  // Skills form state
  const [addingSkill, setAddingSkill] = useState(false)
  const [newSkillName, setNewSkillName] = useState('')
  const [newSkillDesc, setNewSkillDesc] = useState('')
  const [newSkillInstr, setNewSkillInstr] = useState('')
  const [skillSaving, setSkillSaving] = useState(false)
  const [skillError, setSkillError] = useState<string | null>(null)

  useEffect(() => {
    api.providers.list().then(setProviders).catch(() => {})
    api.settings.getDefaultModel().then(r => setDefaultModel(r.value)).catch(() => {})
    api.skills.list().then(setSkills).catch(() => {})
    setMode(getSttMode())
  }, [setProviders, setDefaultModel, setSkills])

  // Reset error when provider type changes or form closes
  function startAdding() {
    setSaveError(null)
    setNewConfig({})
    setNewLabel('')
    setNewProvider('openai')
    setAdding(true)
  }

  function cancelAdding() {
    setAdding(false)
    setSaveError(null)
    setNewLabel('')
    setNewConfig({})
  }

  async function addProvider() {
    // Validate label
    if (!newLabel.trim()) {
      setSaveError('Please enter a display name for this provider.')
      return
    }
    // Validate required fields
    if (newProvider === 'ollama' && !newConfig.api_base?.trim()) {
      setSaveError('Base URL is required. Use http://localhost:11434 for local or https://ollama.com for cloud.')
      return
    }
    if (newProvider === 'anthropic' && !newConfig.api_key?.trim()) {
      setSaveError('API Key is required for Anthropic.')
      return
    }
    if (newProvider === 'openai' && !newConfig.api_key?.trim()) {
      setSaveError('API Key is required for OpenAI.')
      return
    }
    if (newProvider === 'azure') {
      if (!newConfig.api_key?.trim()) { setSaveError('API Key is required for Azure.'); return }
      if (!newConfig.api_base?.trim()) { setSaveError('Endpoint URL is required for Azure.'); return }
      if (!newConfig.api_version?.trim()) { setSaveError('API Version is required for Azure.'); return }
    }

    setSaveError(null)
    setSaving(true)
    try {
      const created = await api.providers.create({
        provider: newProvider,
        label: newLabel.trim(),
        config: newConfig,
        is_default: providers.length === 0,
      })

      // Auto-set default model after save so the user doesn't have to do it manually
      if (newProvider === 'ollama' && providers.length === 0) {
        try {
          const { models } = await api.providers.models(created.id)
          if (models.length > 0) {
            await api.settings.setDefaultModel(`${created.id}::${models[0]}`)
          }
        } catch { /* non-critical */ }
      }
      // Azure: if user filled in default_deployment, auto-set it as the default model
      if (newProvider === 'azure' && newConfig.default_deployment?.trim()) {
        try {
          await api.settings.setDefaultModel(`${created.id}::${newConfig.default_deployment.trim()}`)
        } catch { /* non-critical */ }
      }

      setProviders(await api.providers.list())
      await api.settings.getDefaultModel().then(r => setDefaultModel(r.value)).catch(() => {})
      setAdding(false)
      setNewLabel('')
      setNewConfig({})
    } catch (e: any) {
      // Show the actual error — previously this was silently swallowed
      const msg = e?.message || String(e)
      // Extract the backend detail if it's a JSON error response
      setSaveError(
        msg.includes('{') ? 'Save failed — check your API key and Base URL.' : msg
      )
    } finally {
      setSaving(false)
    }
  }

  async function removeProvider(id: string) {
    try {
      await api.providers.delete(id)
      setProviders(await api.providers.list())
    } catch {}
  }

  async function toggleEnabled(p: Provider) {
    try {
      await api.providers.update(p.id, { enabled: !p.enabled })
      setProviders(await api.providers.list())
    } catch {}
  }

  async function testProvider(id: string) {
    setTestingId(id)
    try {
      const r = await api.providers.test(id)
      setTestResult(prev => ({ ...prev, [id]: { ok: r.ok, message: r.message } }))
    } catch (e: any) {
      setTestResult(prev => ({ ...prev, [id]: { ok: false, message: e.message } }))
    } finally {
      setTestingId(null)
    }
  }

  async function toggleSkill(s: Skill) {
    try { await api.skills.update(s.id, { enabled: !s.enabled }); setSkills(await api.skills.list()) } catch {}
  }

  async function deleteSkill(id: string) {
    try { await api.skills.delete(id); setSkills(await api.skills.list()) } catch {}
  }

  async function addSkill() {
    if (!newSkillName.trim()) {
      setSkillError('Skill name is required.')
      return
    }
    setSkillError(null)
    setSkillSaving(true)
    try {
      await api.skills.create({ name: newSkillName.trim(), description: newSkillDesc, instructions: newSkillInstr })
      setSkills(await api.skills.list())
      setAddingSkill(false)
      setNewSkillName('')
      setNewSkillDesc('')
      setNewSkillInstr('')
    } catch (e: any) {
      setSkillError(e?.message || 'Failed to save skill.')
    } finally {
      setSkillSaving(false)
    }
  }

  // ── Styles ──────────────────────────────────────────────────
  const inputStyle: React.CSSProperties = {
    display: 'block', width: '100%', fontSize: 12, padding: 7, borderRadius: 6,
    background: 'var(--bg-secondary)', color: 'var(--text-primary)',
    border: '0.5px solid var(--border)', boxSizing: 'border-box',
  }
  const btnPrimary: React.CSSProperties = {
    fontSize: 12, padding: '6px 14px', borderRadius: 7, border: 'none',
    background: 'var(--brand-dark)', color: 'white', cursor: 'pointer',
    display: 'flex', alignItems: 'center', gap: 6,
    opacity: saving ? 0.6 : 1,
  }
  const btnSecondary: React.CSSProperties = {
    fontSize: 12, padding: '6px 14px', borderRadius: 7,
    border: '0.5px solid var(--border)', background: 'transparent',
    color: 'var(--text-secondary)', cursor: 'pointer',
  }

  return (
    <div onClick={onClose} style={{
      position: 'fixed', inset: 0, zIndex: 100, background: 'rgba(0,0,0,0.5)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      <div onClick={e => e.stopPropagation()} style={{
        width: 560, maxHeight: '85vh', overflowY: 'auto', background: 'var(--bg-primary)',
        border: '0.5px solid var(--border-strong)', borderRadius: 14, padding: 20,
      }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 16 }}>
          <span style={{ fontSize: 15, fontWeight: 600 }}>Providers</span>
          <button onClick={onClose} style={{ marginLeft: 'auto', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)' }}>
            <X size={18} />
          </button>
        </div>

        {/* Voice input toggle */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14, fontSize: 12, color: 'var(--text-secondary)' }}>
          <span>Voice input</span>
          {(['browser', 'server'] as SttMode[]).map(m => (
            <button key={m} onClick={() => { setSttMode(m); setMode(m) }}
              style={{
                fontSize: 11, padding: '3px 10px', borderRadius: 99, cursor: 'pointer',
                border: '0.5px solid var(--border)',
                background: sttMode === m ? 'rgba(217,119,87,0.14)' : 'var(--bg-tertiary)',
                color: sttMode === m ? 'var(--text-primary)' : 'var(--text-secondary)',
              }}>
              {m === 'browser' ? 'Browser' : 'Server (Whisper)'}
            </button>
          ))}
        </div>

        {/* Existing providers */}
        {providers.map(p => (
          <div key={p.id} style={{ border: '0.5px solid var(--border)', borderRadius: 10, padding: 12, marginBottom: 10 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontSize: 13, fontWeight: 500 }}>{p.label}</span>
              <span style={{ fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase' }}>{p.provider}</span>
              {p.is_default && <span style={{ fontSize: 10, color: 'var(--brand-light)' }}>default</span>}
              <button onClick={() => toggleEnabled(p)} style={{
                marginLeft: 'auto', fontSize: 11, cursor: 'pointer', background: 'var(--bg-tertiary)',
                border: '0.5px solid var(--border)', borderRadius: 6, padding: '2px 8px', color: 'var(--text-secondary)',
              }}>
                {p.enabled ? 'Enabled' : 'Disabled'}
              </button>
              <button
                onClick={() => testProvider(p.id)}
                disabled={testingId === p.id}
                style={{
                  fontSize: 11, cursor: 'pointer', background: 'var(--bg-tertiary)',
                  border: '0.5px solid var(--border)', borderRadius: 6, padding: '2px 8px',
                  color: 'var(--text-secondary)', display: 'flex', alignItems: 'center', gap: 4,
                  opacity: testingId === p.id ? 0.6 : 1,
                }}>
                {testingId === p.id && <Loader2 size={10} style={{ animation: 'spin 1s linear infinite' }} />}
                Test
              </button>
              <button onClick={() => removeProvider(p.id)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)' }}>
                <Trash2 size={14} />
              </button>
            </div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 6 }}>
              {p.provider === 'ollama'
                ? `${p.config?.api_base || '(no URL set)'}${p.has_key ? ' · key ' + p.key_masked : ' · no key'}`
                : p.has_key ? `key ${p.key_masked}` : 'no key'
              }
            </div>
            {testResult[p.id] && (
              <div style={{
                fontSize: 11, marginTop: 6, display: 'flex', alignItems: 'center', gap: 5,
                color: testResult[p.id].ok ? 'var(--green)' : 'var(--red)',
              }}>
                {testResult[p.id].ok ? <CheckCircle2 size={12} /> : <XCircle size={12} />}
                {testResult[p.id].message}
              </div>
            )}
          </div>
        ))}

        {/* Add provider form */}
        {adding ? (
          <div style={{ border: '0.5px solid var(--border-strong)', borderRadius: 10, padding: 14, marginTop: 8 }}>

            {/* Provider type selector */}
            <div style={{ marginBottom: 10 }}>
              <label style={{ display: 'block', fontSize: 11, color: 'var(--text-muted)', marginBottom: 4 }}>Provider type</label>
              <select
                value={newProvider}
                onChange={e => { setNewProvider(e.target.value); setNewConfig({}); setSaveError(null) }}
                style={{ fontSize: 12, padding: 6, borderRadius: 6, background: 'var(--bg-secondary)', color: 'var(--text-primary)', border: '0.5px solid var(--border)' }}>
                <option value="anthropic">Anthropic</option>
                <option value="openai">OpenAI</option>
                <option value="azure">Azure OpenAI</option>
                <option value="ollama">Ollama</option>
              </select>
            </div>

            {/* Ollama quick-fill buttons */}
            {newProvider === 'ollama' && (
              <div style={{
                fontSize: 11, color: 'var(--text-secondary)', background: 'var(--bg-tertiary)',
                border: '0.5px solid var(--border)', borderRadius: 8, padding: 10, marginBottom: 12, lineHeight: 1.5,
              }}>
                <div style={{ fontWeight: 600, color: 'var(--text-primary)', marginBottom: 6 }}>Quick fill</div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <button
                    type="button"
                    onClick={() => {
                      setNewConfig(prev => ({ ...prev, api_base: 'http://localhost:11434', api_key: '' }))
                      if (!newLabel) setNewLabel('Ollama Local')
                      setSaveError(null)
                    }}
                    style={{ fontSize: 11, padding: '4px 10px', borderRadius: 6, border: '0.5px solid var(--border)', background: 'transparent', color: 'var(--text-secondary)', cursor: 'pointer' }}>
                    🖥 Local (localhost)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setNewConfig(prev => ({ ...prev, api_base: 'https://ollama.com', api_key: prev.api_key || '' }))
                      if (!newLabel) setNewLabel('Ollama Cloud')
                      setSaveError(null)
                    }}
                    style={{ fontSize: 11, padding: '4px 10px', borderRadius: 6, border: '0.5px solid var(--border)', background: 'transparent', color: 'var(--text-secondary)', cursor: 'pointer' }}>
                    ☁️ Cloud (ollama.com)
                  </button>
                </div>
                {newConfig.api_base?.includes('ollama.com') && (
                  <div style={{ marginTop: 8, color: 'var(--text-secondary)', fontSize: 10 }}>
                    ☁️ Cloud mode — API Key is required. Get yours at ollama.com/settings/api-keys
                  </div>
                )}
              </div>
            )}

            {/* Label */}
            <div style={{ marginBottom: 10 }}>
              <label style={{ display: 'block', fontSize: 11, color: 'var(--text-muted)', marginBottom: 4 }}>Display name *</label>
              <input
                placeholder="e.g. Ollama Cloud, My Anthropic Key"
                value={newLabel}
                onChange={e => { setNewLabel(e.target.value); setSaveError(null) }}
                style={inputStyle}
              />
            </div>

            {/* Provider-specific fields */}
            {PROVIDER_FIELDS[newProvider].map(f => (
              <div key={f.key} style={{ marginBottom: 10 }}>
                <label style={{ display: 'block', fontSize: 11, color: 'var(--text-muted)', marginBottom: 4 }}>
                  {f.label}
                  {f.key === 'api_base' && newProvider === 'ollama' ? ' *' : ''}
                  {f.key === 'api_key' && newProvider !== 'ollama' ? ' *' : ''}
                  {f.key === 'api_key' && newProvider === 'ollama' && newConfig.api_base?.includes('ollama.com') ? ' *' : ''}
                </label>
                <input
                  placeholder={f.placeholder ?? f.label}
                  type={f.secret ? 'password' : 'text'}
                  autoComplete={f.secret ? 'new-password' : 'off'}
                  value={newConfig[f.key] ?? ''}
                  onChange={e => { setNewConfig(prev => ({ ...prev, [f.key]: e.target.value })); setSaveError(null) }}
                  style={inputStyle}
                />
                {f.helper && (
                  <div style={{ fontSize: 10, color: 'var(--text-muted)', marginTop: 4, lineHeight: 1.4 }}>{f.helper}</div>
                )}
              </div>
            ))}

            {/* Error message — was previously silently swallowed */}
            {saveError && (
              <div style={{
                fontSize: 11, color: 'var(--red)', background: 'rgba(239,68,68,0.08)',
                border: '0.5px solid rgba(239,68,68,0.3)', borderRadius: 6,
                padding: '7px 10px', marginBottom: 10,
                display: 'flex', alignItems: 'flex-start', gap: 6,
              }}>
                <XCircle size={13} style={{ marginTop: 1, flexShrink: 0 }} />
                {saveError}
              </div>
            )}

            <div style={{ display: 'flex', gap: 8 }}>
              <button onClick={addProvider} disabled={saving} style={btnPrimary}>
                {saving && <Loader2 size={12} style={{ animation: 'spin 1s linear infinite' }} />}
                {saving ? 'Saving…' : 'Save'}
              </button>
              <button onClick={cancelAdding} disabled={saving} style={btnSecondary}>Cancel</button>
            </div>
          </div>
        ) : (
          <button onClick={startAdding} style={{
            display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, padding: '8px 14px', marginTop: 8,
            borderRadius: 8, border: '0.5px solid var(--border)', background: 'var(--bg-tertiary)',
            color: 'var(--text-primary)', cursor: 'pointer',
          }}>
            <Plus size={14} /> Add provider
          </button>
        )}

        {/* ── Skills ── */}
        <div style={{ borderTop: '0.5px solid var(--border)', marginTop: 20, paddingTop: 16 }}>
          <span style={{ fontSize: 14, fontWeight: 600 }}>Skills</span>
        </div>

        {skills.map(s => (
          <div key={s.id} style={{ border: '0.5px solid var(--border)', borderRadius: 10, padding: 12, marginBottom: 10, marginTop: 10 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontSize: 13, fontWeight: 500 }}>{s.name}</span>
              {s.description && (
                <span style={{ fontSize: 11, color: 'var(--text-muted)', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{s.description}</span>
              )}
              <button onClick={() => toggleSkill(s)} style={{
                marginLeft: 'auto', fontSize: 11, cursor: 'pointer', background: 'var(--bg-tertiary)',
                border: '0.5px solid var(--border)', borderRadius: 6, padding: '2px 8px', color: 'var(--text-secondary)',
              }}>
                {s.enabled ? 'Enabled' : 'Disabled'}
              </button>
              <button onClick={() => deleteSkill(s.id)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)' }}>
                <Trash2 size={14} />
              </button>
            </div>
          </div>
        ))}

        {addingSkill ? (
          <div style={{ border: '0.5px solid var(--border-strong)', borderRadius: 10, padding: 12, marginTop: 8 }}>
            <input placeholder="Skill name *" value={newSkillName} onChange={e => { setNewSkillName(e.target.value); setSkillError(null) }}
              style={{ ...inputStyle, marginBottom: 8 }} />
            <input placeholder="Description (when to activate)" value={newSkillDesc} onChange={e => setNewSkillDesc(e.target.value)}
              style={{ ...inputStyle, marginBottom: 8 }} />
            <textarea placeholder="Instructions (injected into system prompt)" value={newSkillInstr} onChange={e => setNewSkillInstr(e.target.value)}
              style={{ ...inputStyle, marginBottom: 8, resize: 'vertical', minHeight: 72, fontFamily: 'inherit' }} />
            {skillError && (
              <div style={{ fontSize: 11, color: 'var(--red)', marginBottom: 8, display: 'flex', gap: 5, alignItems: 'center' }}>
                <XCircle size={12} /> {skillError}
              </div>
            )}
            <div style={{ display: 'flex', gap: 8 }}>
              <button onClick={addSkill} disabled={skillSaving} style={btnPrimary}>
                {skillSaving && <Loader2 size={12} style={{ animation: 'spin 1s linear infinite' }} />}
                {skillSaving ? 'Saving…' : 'Save'}
              </button>
              <button onClick={() => { setAddingSkill(false); setSkillError(null) }} style={btnSecondary}>Cancel</button>
            </div>
          </div>
        ) : (
          <button onClick={() => setAddingSkill(true)} style={{
            display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, padding: '8px 14px', marginTop: 8,
            borderRadius: 8, border: '0.5px solid var(--border)', background: 'var(--bg-tertiary)',
            color: 'var(--text-primary)', cursor: 'pointer',
          }}>
            <Plus size={14} /> Add skill
          </button>
        )}
      </div>

      <style>{`@keyframes spin { from { transform: rotate(0deg) } to { transform: rotate(360deg) } }`}</style>
    </div>
  )
}
