#!/usr/bin/env bash
set -e

echo "=== CrewDev Platform ==="
echo "No Docker / Postgres / Redis required."
echo ""

# Create .env if missing
if [ ! -f backend/.env ]; then
  cp backend/.env.example backend/.env
  echo "Created backend/.env — fill in at least one LLM provider key before running."
  echo ""
fi

# Backend
echo "Installing Python deps..."
cd backend
pip install -r requirements.txt -q
echo "Starting backend on :8000 ..."
uvicorn main:app --host 0.0.0.0 --port 8000 --reload &
BACKEND_PID=$!
cd ..

# Frontend
echo "Installing Node deps..."
cd frontend
npm install -q
echo "Starting frontend on :3000 ..."
npm run dev &
FRONTEND_PID=$!
cd ..

echo ""
echo "=== CrewDev running ==="
echo "  Frontend : http://localhost:3000"
echo "  Backend  : http://localhost:8000"
echo "  API docs : http://localhost:8000/docs"
echo "  Database : backend/crewdev.db  (SQLite, auto-created)"
echo ""
echo "Press Ctrl+C to stop."

trap "kill $BACKEND_PID $FRONTEND_PID 2>/dev/null; exit 0" INT TERM
wait
